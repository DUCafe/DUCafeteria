<?php

session_start();
$servername = "localhost";
$username = "root";
$password = "102938";
$dbname = "users";

//create connection
$db = new mysqli($servername, $username, $password, $dbname);

//check connection
if ($db -> connect_error){
	die("connection failed ".$db->connect_error);
}

//success message
echo "connected successfully"."<br>";

/*$alter = "ALTER TABLE MYTABLE
		  MODIFY COLUMN password VARCHAR(100) NOT NULL";
$db->query($alter);*/



if(isset($_POST['register_button']))
{

	$username1 = $_POST['username'];
	$email1 = $_POST['email'];
	$password1 = $_POST['password'];
	$password2 = $_POST['password1'];
	
	//echo "$password1"."<br>";
	//echo "$password2"."<br>";
	
	if($password1 == $password2)
	{
		$password1 = md5($password1);
		$ins_data = "INSERT INTO MYTABLE (username, email, password)
		VALUES ('$username1', '$email1', '$password1')";

		if($db->query($ins_data) == true)
		{
			//echo "inserted. ". "<br>";
			header("Location: login.php");
		}
		else echo "error ".$db->error." <br>";
	}
	else
		echo "Password not matched."."<br>";
}
?>



