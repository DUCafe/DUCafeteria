<!--  <?php
$servername = "localhost";
$username = "root";
$password = "102938";
$dbname = "users";

//create connection
$db = new mysqli($servername, $username, $password, $dbname);

//check connection
if ($db -> connect_error){
	die("connection failed ".$db->connect_error);
}

//success message
echo "connected successfully"."<br>";


//sql command to create a database named users
/* $create_db = "CREATE DATABASE users"; */

//executing command through query function 
/*if($db->query($create_db) == true)
{
	echo "DB created successfully";
}
else echo "Error creation ".$db->error."<br>"; */

//create table commmand
/*$create_table = "CREATE TABLE MYTABLE (
	id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	username VARCHAR(11) NOT NULL,
	email VARCHAR(100) NOT NULL, 
	password VARCHAR(11) NOT NULL
)"; */

//executing command of creating table
/*if($db->query($create_table) == true)
	echo "table created. ". "<br>";
else echo "error ".$db->error." <br>"; */

//Inserting value to table
/* $ins_data = "INSERT INTO MYTABLE (username, email, password)
	VALUES ('HAPPY', 'h@yahoo.com', '12345')";

if($db->query($ins_data) == true)
	echo "inserted. ". "<br>";
else echo "error ".$db->error." <br>"; */

/* $del_data = "DELETE FROM MYTABLE WHERE username = 'HAPPY'";

if($db->query($del_data) == true)
	echo "deleted. ". "<br>";
else echo "error ".$db->error." <br>"; */

echo $_POST['username']."<br>";
echo $_POST['email']."<br>";



$db->close();

?> -->


<!DOCTYPE html>
<html>
<head>
	<title>Form</title>

</head>
<body>
<div class="header">
	<h1>Form</h1>
</div>

<h1>Register</h1>
<span>or <a href="login.php">Login here</a></span>

<form method="post" action="registration.php">
	<table>
		<tr>
			<td>Username:</td>
			<td><input type="text" name="username" class="textInput"></td>
		</tr>
		<tr>
			<td>Email:</td>
			<td><input type="email" name="email" class="textInput"></td>
		</tr>
		<tr>
			<td>Password:</td>
			<td><input type="password" name="password" class="textInput"></td>
		</tr>
		<tr>
			<td>Confirm Password:</td>
			<td><input type="password" name="password1" class="textInput"></td>
		</tr>
		<tr>
			<td><input type="submit" name="register_button" value="Register"></td>
		</tr>
	</table>
</form>
</body>
</html>

























