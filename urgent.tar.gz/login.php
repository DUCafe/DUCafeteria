	<?php
		session_start();
	$servername = "localhost";
	$username = "root";
	$password = "102938";
	$dbname = "users";

	$db = mysqli_connect($servername, $username, $password, $dbname);

	if ($db -> connect_error){
		die("connection failed ".$db->connect_error);
	}

	//success message
	//echo "connected."."<br>";

	
	
	
		if(isset($_POST['login_button']))
		{
		
	
		$username1 = $_POST['username'];
		$password1 = $_POST['password'];
		$password1 = md5($password1);
		//echo "$username1<br>";
		//echo "$password1<br>";
	
		$retrieve_query = "SELECT * FROM MYTABLE where username = '$username1' AND password='$password1'";
						   
						   
		$result = $db->query($retrieve_query);
		$row = $result->num_rows;
		//echo "Result = $row";
		
			if($row == 1)
			{
			
				session_start();
				$_SESSION['login_user'] = $username1;
				echo "<br>Successfully logged in.<br>";
				
				header("location:profile.php"); 
			}
			//else echo "no result found<br>";
		
		//else echo "no result found<br>"; 
		
	}
	?>

	<!DOCTYPE html>
	<html>
	<head>
		<title>Login Page</title>
	</head>
	<body>
	<div class="header">
		<h1>Form</h1>
	</div>

	<h1>Login</h1>
	<span>or <a href="test.php">Register here</a></span>

	<form method="post" action="login.php">
		<table>
			<tr>
				<td>Username:</td>
				<td><input type="text" name="username" class="textInput"></td>
			</tr>
			<tr>
				<td>Password:</td>
				<td><input type="password" name="password" class="textInput"></td>
			</tr>
			<tr>
				<td><input type="submit" name="login_button" value="Log In"></td>
			</tr>
		</table>
	</form>
	</body>
	</html>

























